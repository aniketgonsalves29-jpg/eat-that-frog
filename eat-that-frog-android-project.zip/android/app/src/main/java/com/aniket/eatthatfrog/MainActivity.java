package com.aniket.eatthatfrog;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
